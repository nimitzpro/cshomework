create table ebdb.inflation(
    date Date,
    country varchar(20),
    rate decimal (4,2)
);