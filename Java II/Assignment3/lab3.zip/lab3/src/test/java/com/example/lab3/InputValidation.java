package com.example.lab3;

import org.junit.jupiter.api.Test;

import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

class InputValidation {

    @Test
    public void assertEmailExists(){
        assert HelloController.validateEmail("") != "" : "test failed: should fail empty email";
    }

    @Test
    public void assertEmailFormat(){
        assert HelloController.validateEmail("sdsdsdsdsd") != "" : "test failed: should fail incorrect email format(1)";
        assert HelloController.validateEmail("asweweq2@dd") != "" : "test failed: should fail incorrect email format(2)";
        assert HelloController.validateEmail("@.com") != "" : "test failed: should fail incorrect email format(3)";
    }

    @Test
    public void assertPasswordExists(){
        assert HelloController.validatePassword("") != "" : "test failed: should fail empty password";
    }

    @Test
    public void assertPasswordFormat(){
        assert HelloController.validatePassword("pass") != "" : "test failed: should fail short password";
        assert HelloController.validatePassword("password") != "" : "test failed: should fail letter-only password";
        assert HelloController.validatePassword("password") != "" : "test failed: should fail password without numbers/special chars";
        assert HelloController.validatePassword("password123") != "" : "test failed: should fail password without special chars";
        assert HelloController.validatePassword("password*!") != "" : "test failed: should fail password without numbers";
    }
}