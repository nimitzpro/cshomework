package com.example.lab3;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HelloController{


    @FXML
    private TextField email;

    @FXML
    private PasswordField password;

    @FXML
    private Label response;

    public static String validateEmail(String eText){
        String error = "";
        if (!(Pattern.matches("\\w{1,}@\\w{1,}+\\.\\w{1,3}+", eText))) {
            error = "invalid email format";
        }
        return(error);
    }

    public static String validatePassword(String pText){
        if(pText.length() < 7) {
            return("password not long enough");
        }

        Pattern pattern = Pattern.compile("[a-zA-Z]");
        Matcher matcher = pattern.matcher(pText);

        if(!matcher.find()){
            return("password doesn't have a letter");
        }

        pattern = Pattern.compile("[0-9]");
        matcher = pattern.matcher(pText);

        if(!matcher.find()){
            return("password doesn't have a number");
        }

        pattern = Pattern.compile("[*^&@!]");
        matcher = pattern.matcher(pText);

        if(!matcher.find()){
            return("password doesn't contain any special characters");
        }

        return("");
    }

    @FXML
    protected void clicked() {
        String eText = email.getText();
        String pText = password.getText();

        System.out.println("button clicked, processing email: " + eText + ", password: " + pText);

        String err = validateEmail(eText);
        if(err.length() > 0) {
            response.setText(err);
            return;
        }

        err = validatePassword(pText);
        if(err.length() > 0){
            response.setText(err);
            return;
        }

        response.setText("registration passed!");


    }
}